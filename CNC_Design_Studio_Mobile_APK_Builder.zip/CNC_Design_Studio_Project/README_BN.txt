CNC Design Studio — Installable Trial Project
=============================================

এই ZIP-এ তিনটি অংশ আছে:
- web/index.html: আগের ট্রায়াল অ্যাপ
- windows-app/: Windows Electron অ্যাপের source, installer build করার জন্য
- android-app/: Android Studio project, APK build করার জন্য

সৎ অবস্থা:
এই মুহূর্তে APK বা EXE installer binary তৈরি করা হয়নি। এই পরিবেশে Windows packaging/Android SDK দিয়ে build চালানো হয়নি। এখানে source project এবং build guide তৈরি করা হয়েছে, যাতে Windows কম্পিউটারে সেগুলো build করা যায়।

বর্তমান demo features:
- Design catalog and category filter
- Search
- Favorites
- Add a design
- Demo detail and order button
- Local browser/app storage

এখনো নেই:
- আসল DXF/STL/RLF CNC design files
- CNC toolpath generation / CAM functionality
- Real payment gateway
- Online customer accounts or cloud database
- Secure paid file delivery

প্রথমে Windows কম্পিউটারে Windows build বা Android Studio build চালাতে হবে। Build error এলে error-এর screenshot/text পাঠালে তা ঠিক করতে সাহায্য করা যাবে।
